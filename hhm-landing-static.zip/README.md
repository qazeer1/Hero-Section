# HealthyHotMeal — Static Landing Page
Deploy easily on **Netlify** or **GitHub Pages**.

### Quick Start
1. Create a GitHub repo and push this folder.
2. On Netlify, create a new site from GitHub and deploy.
3. (Optional) Enable Netlify Forms for the signup form.
